<?php
require '../fpdf/fpdf.php';
require 'conexionFUNTION.php'; // Conexión a la base de datos

if(isset($_GET['id'])) {
    $id_ejemplar = preg_replace('/[^0-9]/', '', $_GET['id']); 

    // Consulta para obtener los datos del ejemplar
    $Consulta = "SELECT recordedby, eventDate, country, stateProvince, county, scientificName, recordNumber, ocurrenceRemarks, family, locality, identifiedBy FROM ejemplar WHERE id_ejemplar = $id_ejemplar";
    $resultado = mysqli_query($enlace, $Consulta);

    if (!$resultado) {
        die("Error en la consulta: " . mysqli_error($enlace));
    }

    if (mysqli_num_rows($resultado) == 0) { // Verificar si no hay resultados
        die("No se encontraron datos para el ID: $id_ejemplar");
    }
} else {
    die("ID de ejemplar no proporcionado.");
}

// Crear el PDF
class PDF extends FPDF {
    function Header() {
        $this->SetFont('Arial','B',16);
        $this->Cell(0,10,utf8_decode('Universidad de Pamplona - HERBARIO Catatumbo Sarare'),0,1,'C');
        $this->Ln(10);
    }

    function Footer() {
        $this->SetY(-15);
        $this->SetFont('Arial','I',10);
        $this->Cell(0,10,utf8_decode('Página ').$this->PageNo().'/{nb}',0,0,'C');
    }
}

$pdf = new PDF();
$pdf->AliasNbPages();
$pdf->AddPage();
$pdf->SetFont('Arial','B',14);

// Definir el ancho de las columnas
$ancho_columna = 190; 

// Dibujar tabla con datos más legibles
while($row = mysqli_fetch_assoc($resultado)) {
    $pdf->Cell($ancho_columna,10,'Recolector: '.utf8_decode($row['recordedby']),1,1,'L',0);
    $pdf->Cell($ancho_columna,10,'Fecha: '.$row['eventDate'],1,1,'L',0);
    $pdf->Cell($ancho_columna,10,'Pais: '.$row['country'],1,1,'L',0);
    $pdf->Cell($ancho_columna,10,'Departamento: '.$row['stateProvince'],1,1,'L',0);
    $pdf->Cell($ancho_columna,10,'Municipio: '.$row['county'],1,1,'L',0);
    $pdf->Cell($ancho_columna,10,'Nombre Cientifico: '.utf8_decode($row['scientificName']),1,1,'L',0);
    $pdf->Cell($ancho_columna,10,'No. Registro: '.$row['recordNumber'],1,1,'L',0);
    $pdf->Cell($ancho_columna,10,'caracteristica: '.utf8_decode($row['ocurrenceRemarks']),1,1,'L',0);
    $pdf->Cell($ancho_columna,10,'familia: '.utf8_decode($row['family']),1,1,'L',0);
    $pdf->Cell($ancho_columna,10,'localidad: '.utf8_decode($row['locality']),1,1,'L',0);
    $pdf->Cell($ancho_columna,10,'identificado por: '.utf8_decode($row['identifiedBy']),1,1,'L',0);
    $pdf->Ln(5); // Espacio entre registros
}

$pdf->Output();
?>