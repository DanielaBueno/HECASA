

CREATE TABLE `backups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `filename` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO backups VALUES ('37', 'backup_2025-04-01_04-32-28.sql', '2025-03-31 21:32:28');
INSERT INTO backups VALUES ('38', 'backup_2025-04-01_04-34-00.sql', '2025-03-31 21:34:00');
INSERT INTO backups VALUES ('39', 'backup_2025-04-01_04-34-02.sql', '2025-03-31 21:34:02');
INSERT INTO backups VALUES ('40', 'backup_2025-04-01_04-34-03.sql', '2025-03-31 21:34:03');
INSERT INTO backups VALUES ('41', 'backup_2025-04-01_04-34-04.sql', '2025-03-31 21:34:04');
INSERT INTO backups VALUES ('42', 'backup_2025-04-01_04-34-06.sql', '2025-03-31 21:34:06');
INSERT INTO backups VALUES ('43', 'backup_2025-04-01_04-34-07.sql', '2025-03-31 21:34:07');
INSERT INTO backups VALUES ('44', 'backup_2025-04-01_04-34-10.sql', '2025-03-31 21:34:10');


CREATE TABLE `ejemplar` (
  `id_ejemplar` int(10) unsigned NOT NULL,
  `institutionCode` char(255) DEFAULT NULL,
  `collectionCode` char(255) DEFAULT NULL,
  `recordNumber` int(11) DEFAULT NULL,
  `recordedby` char(255) DEFAULT NULL,
  `eventDate` date DEFAULT NULL,
  `habitat` char(255) DEFAULT NULL,
  `country` char(255) DEFAULT NULL,
  `stateProvince` char(255) DEFAULT NULL,
  `county` char(255) DEFAULT NULL,
  `municipality` char(255) DEFAULT NULL,
  `locality` char(255) DEFAULT NULL,
  `minimumElevationInMeters` int(11) DEFAULT NULL,
  `maximumElevationInMeters` int(11) DEFAULT NULL,
  `verbatimLatitude` char(255) DEFAULT NULL,
  `verbatimLongitude` char(255) DEFAULT NULL,
  `decimalLatitude` char(255) DEFAULT NULL,
  `decimalLongitude` char(255) DEFAULT NULL,
  `geodeticDatum` char(255) DEFAULT NULL,
  `identifiedBy` char(255) DEFAULT NULL,
  `dateIdentified` date DEFAULT NULL,
  `scientificName` char(255) DEFAULT NULL,
  `identificationQualifier` char(255) DEFAULT NULL,
  `reproductiveCondition` char(255) DEFAULT NULL,
  `ocurrenceRemarks` text DEFAULT NULL,
  `kingdom` char(255) DEFAULT NULL,
  `class` char(255) DEFAULT NULL,
  `orderr` char(255) DEFAULT NULL,
  `family` char(255) DEFAULT NULL,
  `genus` char(255) DEFAULT NULL,
  `specificEpithet` char(255) DEFAULT NULL,
  `taxonRank` char(255) DEFAULT NULL,
  `scientificNameAuthorship` char(255) DEFAULT NULL,
  `id_usuario` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id_ejemplar`),
  KEY `id_usuario` (`id_usuario`),
  CONSTRAINT `ejemplar_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO ejemplar VALUES ('909', 'Pamplona', 'vyy', '3434', 'Juan Camilo', '2025-03-26', 'si sirve?', 'colombia', 'Norte santander', 'Pamplona', 'Monte', 'puro monte', '8778', '78', '34', 'ybghu', '2345', '5678', 'byhun', 'ybhun', '2025-03-18', 'Listo ahora si sirve', 'bghn', 'ahora si ?', 'kjibn', 'byuhnij', 'byhunj', 'bgyhunj', 'gybhnj', 'gbhnj', 'gbhnj', 'vgybh', 'bebe', '1');
INSERT INTO ejemplar VALUES ('1010', 'ctfvgbh', 'ybuhnj', '67', 'Juan Camilo', '2025-03-24', 'trvgy', 'Colombia', 'g7yuhb', 'byguguhb', 'buibiu', 'buuib', '98', '8697', 'vygv', 'vyvi', 'yuvyuv', 'yuvu', 'vyuv', 'yvuuy', '2025-03-13', 'vuyu', 'yvuv', 'vyuv', 'vyuv', 'vuy', 'vyuv', 'vuyv', 'vuyvyu', 'ytft', 'tydfty', 'tdtf', 'yft', '1');
INSERT INTO ejemplar VALUES ('13722', 'Universidad de Pamplona (Upamplona)', 'HECASA', '7558', 'Luis Roberto Sánchez', '0000-00-00', '', 'Colombia', 'Norte de Santander', 'Pamplonita', '', 'Vereda Matajira, Granja Experimental Villa Marina', '1300', '1500', '07°31\'54\'N', '73°37\'42\'W', '', '', 'WGS84', '', '', 'Sphaeradenia', '', 'Vegetativo', '', 'Plantae', 'Equisetopsida', 'Pandanales', 'Cyclanthaceae', 'Sphaeradenia', '', 'Género', '', '2');


CREATE TABLE `informe` (
  `id_informe` int(10) unsigned NOT NULL,
  `fecha_informe` date DEFAULT NULL,
  `formato` enum('PDF','CSV','Excel') DEFAULT NULL,
  `id_usuario` int(10) unsigned DEFAULT NULL,
  `id_ejemplar` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id_informe`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_ejemplar` (`id_ejemplar`),
  CONSTRAINT `informe_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`),
  CONSTRAINT `informe_ibfk_2` FOREIGN KEY (`id_ejemplar`) REFERENCES `ejemplar` (`id_ejemplar`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



CREATE TABLE `rol` (
  `id_rol` int(10) unsigned NOT NULL,
  `nombreRol` char(255) DEFAULT NULL,
  `descripcionRol` char(255) DEFAULT NULL,
  PRIMARY KEY (`id_rol`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO rol VALUES ('1', 'Administrador', 'Es el administrador del programa y tiene acceso a todas las opciones');
INSERT INTO rol VALUES ('2', 'Usuario', 'Es el usuario del programa y solo tiene acceso a ciertas opciones');


CREATE TABLE `sesionh` (
  `id_sesion` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_sesion` char(255) DEFAULT NULL,
  `fecha_sesion` datetime DEFAULT NULL,
  `estado` char(255) DEFAULT NULL,
  PRIMARY KEY (`id_sesion`)
) ENGINE=InnoDB AUTO_INCREMENT=121 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO sesionh VALUES ('100', 'Juan Camilo', '2025-03-31 21:37:34', 'Inició sesión');
INSERT INTO sesionh VALUES ('101', 'Juan Camilo', '2025-03-31 21:41:05', 'Inició sesión');
INSERT INTO sesionh VALUES ('102', 'Juan Camilo', '2025-03-31 21:41:57', 'Inició sesión');
INSERT INTO sesionh VALUES ('103', 'Jessica Sarmiento', '2025-03-31 21:42:07', 'Inició sesión');
INSERT INTO sesionh VALUES ('104', 'Jessica Sarmiento', '2025-03-31 21:43:53', 'Inició sesión');
INSERT INTO sesionh VALUES ('105', 'Juan Camilo', '2025-03-31 22:33:40', 'Inició sesión');
INSERT INTO sesionh VALUES ('106', 'Jessica Sarmiento', '2025-04-01 09:26:38', 'Inició sesión');
INSERT INTO sesionh VALUES ('107', 'Jessica Sarmiento', '2025-04-01 09:41:39', 'Inició sesión');
INSERT INTO sesionh VALUES ('108', 'Jessica Sarmiento', '2025-04-01 09:42:39', 'Inició sesión');
INSERT INTO sesionh VALUES ('109', 'Jessica Sarmiento', '2025-04-01 09:45:02', 'Inició sesión');
INSERT INTO sesionh VALUES ('110', 'Jessica Sarmiento', '2025-04-01 09:53:51', 'Inició sesión');
INSERT INTO sesionh VALUES ('111', 'Jessica Sarmiento', '2025-04-01 09:54:17', 'Inició sesión');
INSERT INTO sesionh VALUES ('112', 'Jessica Sarmiento', '2025-04-01 09:54:42', 'Inició sesión');
INSERT INTO sesionh VALUES ('113', 'Jessica Sarmiento', '2025-04-01 10:42:26', 'Inició sesión');
INSERT INTO sesionh VALUES ('114', 'Jessica Sarmiento', '2025-04-01 10:57:12', 'Inició sesión');
INSERT INTO sesionh VALUES ('115', 'Jessica Sarmiento', '2025-04-01 11:04:33', 'Inició sesión');
INSERT INTO sesionh VALUES ('116', 'Jessica Sarmiento', '2025-04-01 11:04:51', 'Inició sesión');
INSERT INTO sesionh VALUES ('117', 'Juan Camilo', '2025-04-01 11:09:25', 'Inició sesión');
INSERT INTO sesionh VALUES ('118', 'Jessica Sarmiento', '2025-04-01 11:15:55', 'Inició sesión');
INSERT INTO sesionh VALUES ('119', 'Jessica Sarmiento', '2025-04-01 19:31:41', 'Inició sesión');
INSERT INTO sesionh VALUES ('120', 'Jessica Sarmiento', '2025-04-01 19:32:44', 'Inició sesión');


CREATE TABLE `usuario` (
  `id_usuario` int(10) unsigned NOT NULL,
  `nombre_usuario` char(255) DEFAULT NULL,
  `contrasena_usuario` char(255) DEFAULT NULL,
  `id_rol` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id_usuario`),
  KEY `id_rol` (`id_rol`),
  CONSTRAINT `usuario_ibfk_1` FOREIGN KEY (`id_rol`) REFERENCES `rol` (`id_rol`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO usuario VALUES ('1', 'Jessica Sarmiento', 'dueña', '1');
INSERT INTO usuario VALUES ('2', 'Juan Camilo', 'dueño', '2');
